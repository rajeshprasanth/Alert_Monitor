#---------------------------------------------------------------------------------------------------------------------------------------------
# This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the 
# Free Software Foundation, either version 3 of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or 
# FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License along with this program. If not, see <https://www.gnu.org/licenses/>. 
#---------------------------------------------------------------------------------------------------------------------------------------------
from functools import wraps
from apps.api.models import db,Alert,Response,ApiKey
from flask import request, abort

# The actual decorator function
def require_api_key(view_function):
    @wraps(view_function)
    # the new, post-decoration function. Note *args and **kwargs here.
    def decorated_function(*args, **kwargs):
        
        # Get the input Trigger source name, api_key_name and api_key_hash
        input_api_key_hash = request.headers.get('x-api-key') 
        # get the stored api_key from database
        result = db.session.query(ApiKey).all()
        
        db_api_key_hash= []
        
        for row in result:
            db_api_key_hash.append(row.ApiKeyHash)
        
        if not input_api_key_hash:
            return_msg = "Missing api key."
            abort(401,return_msg)
            
        if input_api_key_hash and input_api_key_hash in  db_api_key_hash:
                return view_function(*args, **kwargs)
        else:
            return_msg = "Incorrect api key."
            abort(401,return_msg)

    return decorated_function
