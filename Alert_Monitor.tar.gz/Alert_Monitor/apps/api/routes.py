#---------------------------------------------------------------------------------------------------------------------------------------------
# This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the 
# Free Software Foundation, either version 3 of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or 
# FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License along with this program. If not, see <https://www.gnu.org/licenses/>. 
#---------------------------------------------------------------------------------------------------------------------------------------------
from flask import Blueprint, render_template, jsonify, request,abort

from .models import db,Alert,Response,ApiKey

from .auth import require_api_key

routes_bp = Blueprint("routes_bp", __name__)


@routes_bp.route("/api/alerts/insert", methods=["POST"])
@require_api_key
def insert_alert():
    alert_details = request.get_json()
    
    if alert_details["AlertName"] or alert_details["AlertStatus"] or alert_details["AlertMsg"] or alert_details["AlertLevel"] or alert_details["TriggerTime"] or  alert_details["TriggerSource"] :
        try:
            table_row = Alert(
            AlertName = alert_details["AlertName"], 
            AlertStatus = alert_details["AlertStatus"], 
            AlertMsg = alert_details["AlertMsg"], 
            AlertLevel = alert_details["AlertLevel"], 
            TriggerTime = alert_details["TriggerTime"], 
            TriggerSource = alert_details["TriggerSource"]
            )
            db.session.add(table_row)
            db.session.commit()
            result = db.session.query(Alert).order_by(Alert.AlertId.desc()).first()
        except:
            db.session.rollback()
            return_msg = "Something is wrong in POST request to /api/alerts/insert"
            abort(401,return_msg)
    else:
        return_msg = "Insufficient arguments in POST request to /api/alerts/insert"
        abort(401,return_msg)
    return jsonify(result)
    
    
    

@routes_bp.route("/api/alerts/update", methods=["PUT"])
@require_api_key
def update_alert():
    alert_details = request.get_json()
    
    curr_row = alert_details["AlertId"]
    last_row = db.session.query(Alert).order_by(Alert.AlertId.desc()).first()
    last_row = last_row.AlertId
    
    if int(last_row) < int(curr_row):
        return_msg = "Unable to find AlertId : " +  str(curr_row) + ". Last AlertId is : " + str(last_row)
        abort(401,return_msg)
        
    if alert_details["ResponseMsg"] or alert_details["ResponseTime"] or alert_details["UpdatedBy"] or alert_details["AlertStatus"] or alert_details["AlertId"]:
        try:
            table_row = alert_details["AlertId"]
            db.session.query(Alert).filter(Alert.AlertId == table_row).update({
            Alert.ResponseMsg: alert_details["ResponseMsg"],
            Alert.ResponseTime: alert_details["ResponseTime"],
            Alert.UpdatedBy: alert_details["UpdatedBy"],
            Alert.AlertStatus: alert_details["AlertStatus"]
            })
            db.session.commit()
            result = db.session.query(Alert).filter(Alert.AlertId == table_row).one()
        except:
            db.session.rollback()
            return_msg = "Unable to update alert through PUT request to /api/alerts/update"
            abort(401,return_msg)
            
        try:
            response_table_row = Response(AlertId = alert_details["AlertId"], 
            ResponseMsg = alert_details["ResponseMsg"], 
            ResponseTime = alert_details["ResponseTime"], 
            UpdatedBy = alert_details["UpdatedBy"], 
            AlertStatus = alert_details["AlertStatus"]
            )
            db.session.add(response_table_row)
            db.session.commit()
            
        except:
            db.session.rollback()
            return_msg = "Unable to update response alert through PUT request to /api/alerts/update"
            abort(401,return_msg)
            
    else:
        return_msg = "Insufficient arguments in PUT request to /api/alerts/update"
        abort(401,return_msg)
        
    return jsonify(result)

@routes_bp.route("/api/alerts/delete", methods=["DELETE"])
@require_api_key
def delete_alert():
    alert_details = request.get_json()
    try:
        table_row = alert_details["AlertId"]
        delete_row = db.session.query(Alert).filter(Alert.AlertId == table_row).one()
        db.session.delete(delete_row)
        db.session.commit()
    except:
        db.session.rollback()
        return_msg = "Unable to delete alert through DELETE request to /api/alerts/delete"
        abort(401,return_msg)
    return jsonify(delete_row)
    
    
@routes_bp.route('/api/alerts', methods=["GET"])
@require_api_key
def get_alerts():
    try:
        result = db.session.query(Alert).all()
    except:
        abort(404,"Alerts not found")
    return jsonify(result) 
    
@routes_bp.route("/api/alerts/<int:AlertId>", methods=["GET"])
@require_api_key
def get_alert_by_alertid(AlertId):
    try:
        table_row = AlertId
        result = db.session.query(Alert).filter(Alert.AlertId == table_row).one()
    except:
        return_msg = "/api/alerts/" + str(table_row) + " not found"
        abort(401,return_msg)
    return jsonify(result)    