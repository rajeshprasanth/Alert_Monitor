#---------------------------------------------------------------------------------------------------------------------------------------------
# This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the 
# Free Software Foundation, either version 3 of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or 
# FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License along with this program. If not, see <https://www.gnu.org/licenses/>. 
#---------------------------------------------------------------------------------------------------------------------------------------------
import os.path
import sys

# directory reach
directory = os.path.dirname(os.path.abspath("__file__"))
# setting path
sys.path.append(os.path.dirname(os.path.dirname(directory)))


# Flask Import
from flask_sqlalchemy import SQLAlchemy
from flask import Flask
from flask_login import LoginManager 

db = SQLAlchemy()
login_manager = LoginManager()
login_manager.login_view = 'auth.login'

    
def register_extensions(app):
    db.init_app(app)
    login_manager.init_app(app)
    
@login_manager.user_loader
def load_user(user_id):
    from apps.client.models import Users
    return Users.query.get(user_id)
        
def register_blueprints(app):
    from apps.client import routes
    app.register_blueprint(routes.routes_bp)
    from apps.client import auth
    app.register_blueprint(auth.auth_bp)
    
def configure_database(app):
    db.create_all()

    @app.teardown_request
    def shutdown_session(exception=None):
        db.session.remove()
        
def create_app(config_class):
    app = Flask(__name__)
    app.config.from_object(config_class)
    
    with app.app_context():
            register_extensions(app)
            register_blueprints(app)
            configure_database(app)
    
    @app.route('/testpage/')
    def test_page():
        return '<h1>Testing page for the Flask Application Factory Pattern</h1>'
        
    return app