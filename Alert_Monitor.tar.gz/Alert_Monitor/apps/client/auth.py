#---------------------------------------------------------------------------------------------------------------------------------------------
# This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the 
# Free Software Foundation, either version 3 of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or 
# FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License along with this program. If not, see <https://www.gnu.org/licenses/>. 
#---------------------------------------------------------------------------------------------------------------------------------------------
from flask import Blueprint,render_template, redirect, url_for, request,flash
from apps.client.models import db,Users

from flask_login import LoginManager

from werkzeug.security import generate_password_hash, check_password_hash
from flask_login import login_user, logout_user, login_required,current_user

# Import version, date string method
from apps.utils.get_version import get_version
from apps.utils.get_date_string import get_date_string

from sqlalchemy import text,select


auth_bp = Blueprint('auth', __name__)


    
    
@auth_bp.route('/')
def login():

    ti_string = 'Alert Monitor - Login'
    dt_string = get_date_string()
    ver_string = get_version()
    
    return render_template('login_template.html', 
    title_string = ti_string,
    date_string = dt_string, 
    version_string = ver_string)



@auth_bp.route('/login', methods=['POST'])
def login_post():
    username = request.form.get('username')
    password = request.form.get('password')
    remember = True if request.form.get('remember') else False

    
    user = db.session.query(Users).filter(Users.UsersName == username).scalar()

    
    # check if user actually exists
    # take the user supplied password, hash it, and compare it to the hashed password in database
    if not user or not check_password_hash(user.UsersPassword, password): 
        flash('Please check your login details and try again.')
        return redirect(url_for('auth.login')) # if user doesn't exist or password is wrong, reload the page

    # if the above check passes, then we know the user has the right credentials
    login_user(user, remember=remember)
    return redirect(url_for('routes_bp.eventmanager'))


@auth_bp.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('auth.login'))

@auth_bp.route('/profile')
@login_required
def profile():

    ti_string = 'Alert Monitor - Login'
    dt_string = get_date_string()
    ver_string = get_version()
    user_string = current_user.UsersName
    
     
    return render_template('profile_template.html', 
    title_string = ti_string,
    date_string = dt_string, 
    version_string = ver_string, 
    username_string = user_string)
    
    
    
@auth_bp.route('/profile_update_username', methods=['POST'])
def profile_update_username():
    currentusername = request.form.get('currentusername')
    newusername = request.form.get('newusername')
    confirmusername = request.form.get('confirmusername')

    loggedinusername = current_user.UsersName
    
    user = db.session.query(Users).filter(Users.UsersName == currentusername).scalar()
    
    temp = db.session.execute(text("SELECT UsersName FROM USERS_TABLE")).scalars()
    
    users_in_db = []
    
    for row in temp:
        users_in_db.append(row)
    

    if loggedinusername != currentusername:
        flash('Cannot change username for another user.','username')
    elif newusername in users_in_db:
        flash('Choose another username.','username')
    elif not user:
        flash('Username does not exist.','username')
    elif currentusername == newusername:
        flash('New username and old username cannot be same','username')
    elif newusername != confirmusername:
        flash('Username does not match','username')
    else:
        try:
            db.session.query(Users).filter(Users.UsersName == currentusername).update({Users.UsersName: newusername})
            db.session.commit()
            flash('Username has been updated successfully. Please login back.','username')
            
        except:
            db.session.rollback()
            flash('Unable to update to username. Try after sometime.','username')
            redirect(url_for('auth.profile'))
            
    return redirect(url_for('auth.profile'))
    
    
    
@auth_bp.route('/profile_update_password', methods=['POST'])
def profile_update_password():
    currentusername = request.form.get('currentusername')
    currentpassword = request.form.get('currentpassword')
    newpassword = request.form.get('newpassword')
    confirmpassword = request.form.get('confirmpassword')
    loggedinusername = current_user.UsersName
    
    user = db.session.query(Users).filter(Users.UsersName == currentusername).scalar()
    
    
    if loggedinusername != currentusername:
        flash('Cannot change password for another user.','password') 
    elif not user:
        flash('Username does not exist.','password')
    elif not check_password_hash(user.UsersPassword, currentpassword): 
        flash('Current password does not match.','password')
    elif currentpassword == newpassword:
        flash('New password and old password cannot be same','password')
    elif newpassword != confirmpassword:
        flash('Password does not match','password')
    else:
        temp = generate_password_hash(newpassword, method = 'scrypt' )
        try:
            db.session.query(Users).filter(Users.UsersName == currentusername).update({Users.UsersPassword: temp})
            db.session.commit()
            flash('Password has been updated successfully. Please login back.','password')
            
        except:
            db.session.rollback()
            flash('Unable to update to password. Try after sometime.','password')
            redirect(url_for('auth.profile'))
    
    
    return redirect(url_for('auth.profile'))
    