#---------------------------------------------------------------------------------------------------------------------------------------------
# This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the 
# Free Software Foundation, either version 3 of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or 
# FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License along with this program. If not, see <https://www.gnu.org/licenses/>. 
#---------------------------------------------------------------------------------------------------------------------------------------------
import os.path
import sys


# directory reach
directory = os.path.dirname(os.path.abspath("__file__"))
# setting path
sys.path.append(os.path.dirname(os.path.dirname(directory)))

from apps.client import db
from dataclasses import dataclass
from flask_login import UserMixin

@dataclass
class Alert(db.Model):
    __tablename__ = "ALERT_TABLE"
    
    AlertId:int
    AlertName:str
    AlertStatus:str
    AlertMsg:str
    AlertLevel:str
    TriggerTime:str
    TriggerSource:str
    ResponseMsg:str
    ResponseTime:str
    UpdatedBy:str
    
    AlertId = db.Column(db.Integer, primary_key=True, autoincrement=True)
    AlertName  = db.Column(db.String(256), index=True)
    AlertStatus = db.Column(db.String(16), index=True)
    AlertMsg = db.Column(db.String(512))
    AlertLevel = db.Column(db.String(16), index=True)
    TriggerTime = db.Column(db.String(16))
    TriggerSource = db.Column(db.String(16), index=True)
    ResponseMsg = db.Column(db.String(512))
    ResponseTime = db.Column(db.String(16))
    UpdatedBy = db.Column(db.String(16), index=True)
    
@dataclass
class Response(db.Model):
    __tablename__ = "RESPONSE_TABLE"
    
    ResponseId:int
    AlertId:int
    ResponseMsg:str
    ResponseTime:str
    UpdatedBy:str
    AlertStatus:str
    
    ResponseId = db.Column(db.Integer, primary_key=True, autoincrement=True)
    AlertId = db.Column(db.Integer, index=True)
    ResponseMsg = db.Column(db.String(512))
    ResponseTime = db.Column(db.String(16))
    UpdatedBy = db.Column(db.String(16), index=True)
    AlertStatus = db.Column(db.String(16), index=True)

@dataclass
class ApiKey(db.Model):
    __tablename__ = 'API_KEY_TABLE'
     
    ApiKeyId:int
    ApiKeyName:str
    ApiKeyHash:str
    
    ApiKeyId = db.Column(db.Integer, primary_key = True, autoincrement=True)
    ApiKeyName = db.Column(db.String(2048))
    ApiKeyHash = db.Column(db.String(2048))

@dataclass
class Users(UserMixin,db.Model):
    __tablename__ = 'USERS_TABLE'
    UsersId = db.Column(db.Integer, primary_key=True,autoincrement=True)
    UsersName = db.Column(db.String(128))
    UsersPassword = db.Column(db.String(2048))
    def get_id(self):
        return (self.UsersId)
