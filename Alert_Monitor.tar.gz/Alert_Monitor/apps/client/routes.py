#---------------------------------------------------------------------------------------------------------------------------------------------
# This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the 
# Free Software Foundation, either version 3 of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or 
# FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License along with this program. If not, see <https://www.gnu.org/licenses/>. 
#---------------------------------------------------------------------------------------------------------------------------------------------
from flask import Blueprint, render_template, jsonify, request,abort

from flask_login import login_required, current_user

from .models import db,Alert,Response,ApiKey

from datetime import datetime

routes_bp = Blueprint("routes_bp", __name__)

from sqlalchemy import text,select

# Import version, date string method
from apps.utils.get_version import get_version
from apps.utils.get_date_string import get_date_string


@routes_bp.route('/eventmanager')
@login_required
def eventmanager():
    #
    # Query ALERT_TABLE with model object Alert
    #
    alerts = db.session.query(Alert)
    #
    # Generate date, version, current logged in username,title
    #
    ti_string = 'Alert Monitor - Event Manager'
    dt_string = get_date_string()
    ver_string = get_version()
    user_string = current_user.UsersName
    #
    #
    alerts_cnt = {
    "open_tot" : db.session.execute(text("SELECT COUNT(*) FROM ALERT_TABLE WHERE AlertStatus = 'Open'")).scalar(),
    "open_info" : db.session.execute(text("SELECT COUNT(*) FROM ALERT_TABLE WHERE AlertStatus = 'Open' AND AlertLevel = 'Information'")).scalar(),
    "open_warn" : db.session.execute(text("SELECT COUNT(*) FROM ALERT_TABLE WHERE AlertStatus = 'Open' AND AlertLevel = 'Warning'")).scalar(),
    "open_error" : db.session.execute(text("SELECT COUNT(*) FROM ALERT_TABLE WHERE AlertStatus = 'Open' AND AlertLevel = 'Error'")).scalar(),
    "open_crit" : db.session.execute(text("SELECT COUNT(*) FROM ALERT_TABLE WHERE AlertStatus = 'Open' AND AlertLevel = 'Critical'")).scalar(),
    "pend_tot" : db.session.execute(text("SELECT COUNT(*) FROM ALERT_TABLE WHERE AlertStatus = 'Pending'")).scalar(),
    "pend_info" : db.session.execute(text("SELECT COUNT(*) FROM ALERT_TABLE WHERE AlertStatus = 'Pending' AND AlertLevel = 'Information'")).scalar(),
    "pend_warn" : db.session.execute(text("SELECT COUNT(*) FROM ALERT_TABLE WHERE AlertStatus = 'Pending' AND AlertLevel = 'Warning'")).scalar(),
    "pend_error" : db.session.execute(text("SELECT COUNT(*) FROM ALERT_TABLE WHERE AlertStatus = 'Pending' AND AlertLevel = 'Error'")).scalar(),
    "pend_crit" : db.session.execute(text("SELECT COUNT(*) FROM ALERT_TABLE WHERE AlertStatus = 'Pending' AND AlertLevel = 'Critical'")).scalar(),
    "close_tot" : db.session.execute(text("SELECT COUNT(*) FROM ALERT_TABLE WHERE AlertStatus = 'Closed'")).scalar(),
    "close_info" : db.session.execute(text("SELECT COUNT(*) FROM ALERT_TABLE WHERE AlertStatus = 'Closed' AND AlertLevel = 'Information'")).scalar(),
    "close_warn" : db.session.execute(text("SELECT COUNT(*) FROM ALERT_TABLE WHERE AlertStatus = 'Closed' AND AlertLevel = 'Warning'")).scalar(),
    "close_error" : db.session.execute(text("SELECT COUNT(*) FROM ALERT_TABLE WHERE AlertStatus = 'Closed' AND AlertLevel = 'Error'")).scalar(),
    "close_crit" : db.session.execute(text("SELECT COUNT(*) FROM ALERT_TABLE WHERE AlertStatus = 'Closed' AND AlertLevel = 'Critical'")).scalar(),
    }
    
    return render_template('eventmanager_template.html', alerts=alerts, alerts_cnt_template = alerts_cnt,
    title_string = ti_string,
    date_string = dt_string, 
    version_string = ver_string, 
    username_string = user_string)
    
@routes_bp.route('/statistics')
@login_required
def statistics():

    #
    # Generate date, version, current logged in username,title
    #
    ti_string = 'Alert Monitor - Statistics'
    dt_string = get_date_string()
    ver_string = get_version()
    user_string = current_user.UsersName
    #
    #
    alerts_cnt = {
    "open_tot" : db.session.execute(text("SELECT COUNT(*) FROM ALERT_TABLE WHERE AlertStatus = 'Open'")).scalar(),
    "open_info" : db.session.execute(text("SELECT COUNT(*) FROM ALERT_TABLE WHERE AlertStatus = 'Open' AND AlertLevel = 'Information'")).scalar(),
    "open_warn" : db.session.execute(text("SELECT COUNT(*) FROM ALERT_TABLE WHERE AlertStatus = 'Open' AND AlertLevel = 'Warning'")).scalar(),
    "open_error" : db.session.execute(text("SELECT COUNT(*) FROM ALERT_TABLE WHERE AlertStatus = 'Open' AND AlertLevel = 'Error'")).scalar(),
    "open_crit" : db.session.execute(text("SELECT COUNT(*) FROM ALERT_TABLE WHERE AlertStatus = 'Open' AND AlertLevel = 'Critical'")).scalar(),
    "pend_tot" : db.session.execute(text("SELECT COUNT(*) FROM ALERT_TABLE WHERE AlertStatus = 'Pending'")).scalar(),
    "pend_info" : db.session.execute(text("SELECT COUNT(*) FROM ALERT_TABLE WHERE AlertStatus = 'Pending' AND AlertLevel = 'Information'")).scalar(),
    "pend_warn" : db.session.execute(text("SELECT COUNT(*) FROM ALERT_TABLE WHERE AlertStatus = 'Pending' AND AlertLevel = 'Warning'")).scalar(),
    "pend_error" : db.session.execute(text("SELECT COUNT(*) FROM ALERT_TABLE WHERE AlertStatus = 'Pending' AND AlertLevel = 'Error'")).scalar(),
    "pend_crit" : db.session.execute(text("SELECT COUNT(*) FROM ALERT_TABLE WHERE AlertStatus = 'Pending' AND AlertLevel = 'Critical'")).scalar(),
    "close_tot" : db.session.execute(text("SELECT COUNT(*) FROM ALERT_TABLE WHERE AlertStatus = 'Closed'")).scalar(),
    "close_info" : db.session.execute(text("SELECT COUNT(*) FROM ALERT_TABLE WHERE AlertStatus = 'Closed' AND AlertLevel = 'Information'")).scalar(),
    "close_warn" : db.session.execute(text("SELECT COUNT(*) FROM ALERT_TABLE WHERE AlertStatus = 'Closed' AND AlertLevel = 'Warning'")).scalar(),
    "close_error" : db.session.execute(text("SELECT COUNT(*) FROM ALERT_TABLE WHERE AlertStatus = 'Closed' AND AlertLevel = 'Error'")).scalar(),
    "close_crit" : db.session.execute(text("SELECT COUNT(*) FROM ALERT_TABLE WHERE AlertStatus = 'Closed' AND AlertLevel = 'Critical'")).scalar(),
    }
    #print(alerts_cnt)
    top_5_triggersrc_key = []
    top_5_triggersrc_cnt = []
    #
    top_5_alerts_key = []
    top_5_alerts_cnt = []
    #
    top_5_updaters_key = []
    top_5_updaters_cnt = []
    #
    triggersrc = db.session.execute(text("SELECT TriggerSource, count(TriggerSource) FROM ALERT_TABLE GROUP BY TriggerSource ORDER BY count(TriggerSource) DESC LIMIT 5;"))
    alertsname = db.session.execute(text("SELECT AlertName, count(AlertName) FROM ALERT_TABLE GROUP BY AlertName ORDER BY count(AlertName) DESC LIMIT 5;"))
    updaters = db.session.execute(text("SELECT UpdatedBy, count(UpdatedBy) FROM ALERT_TABLE GROUP BY UpdatedBy ORDER BY count(UpdatedBy) DESC LIMIT 5;"))
    
    for row in triggersrc:
        top_5_triggersrc_key.append(row[0])
        top_5_triggersrc_cnt.append(row[1])
    
    for row in alertsname:
        top_5_alerts_key.append(row[0])
        top_5_alerts_cnt.append(row[1])
    #
    for row in updaters:
        top_5_updaters_key.append(row[0])
        top_5_updaters_cnt.append(row[1])
    
 
    return render_template('statistics_template.html', alerts_cnt_template = alerts_cnt,
    top_5_triggersrc_key_template = top_5_triggersrc_key ,
    top_5_triggersrc_cnt_template = top_5_triggersrc_cnt,
    top_5_alerts_key_template = top_5_alerts_key,
    top_5_alerts_cnt_template = top_5_alerts_cnt,
    top_5_updaters_key_template = top_5_updaters_key ,
    top_5_updaters_cnt_template = top_5_updaters_cnt,
    title_string = ti_string,
    date_string = dt_string, 
    version_string = ver_string, 
    username_string = user_string
    )

@routes_bp.route('/dashboard')
@login_required
def dashboard():
    #
    # Generate date, version, current logged in username,title
    #
    ti_string = 'Alert Monitor - Dashboard'
    dt_string = get_date_string()
    ver_string = get_version()
    user_string = current_user.UsersName
    #
    #
    alerts_cnt = {
    "open_tot" : db.session.execute(text("SELECT COUNT(*) FROM ALERT_TABLE WHERE AlertStatus = 'Open'")).scalar(),
    "open_info" : db.session.execute(text("SELECT COUNT(*) FROM ALERT_TABLE WHERE AlertStatus = 'Open' AND AlertLevel = 'Information'")).scalar(),
    "open_warn" : db.session.execute(text("SELECT COUNT(*) FROM ALERT_TABLE WHERE AlertStatus = 'Open' AND AlertLevel = 'Warning'")).scalar(),
    "open_error" : db.session.execute(text("SELECT COUNT(*) FROM ALERT_TABLE WHERE AlertStatus = 'Open' AND AlertLevel = 'Error'")).scalar(),
    "open_crit" : db.session.execute(text("SELECT COUNT(*) FROM ALERT_TABLE WHERE AlertStatus = 'Open' AND AlertLevel = 'Critical'")).scalar(),
    "pend_tot" : db.session.execute(text("SELECT COUNT(*) FROM ALERT_TABLE WHERE AlertStatus = 'Pending'")).scalar(),
    "pend_info" : db.session.execute(text("SELECT COUNT(*) FROM ALERT_TABLE WHERE AlertStatus = 'Pending' AND AlertLevel = 'Information'")).scalar(),
    "pend_warn" : db.session.execute(text("SELECT COUNT(*) FROM ALERT_TABLE WHERE AlertStatus = 'Pending' AND AlertLevel = 'Warning'")).scalar(),
    "pend_error" : db.session.execute(text("SELECT COUNT(*) FROM ALERT_TABLE WHERE AlertStatus = 'Pending' AND AlertLevel = 'Error'")).scalar(),
    "pend_crit" : db.session.execute(text("SELECT COUNT(*) FROM ALERT_TABLE WHERE AlertStatus = 'Pending' AND AlertLevel = 'Critical'")).scalar(),
    "close_tot" : db.session.execute(text("SELECT COUNT(*) FROM ALERT_TABLE WHERE AlertStatus = 'Closed'")).scalar(),
    "close_info" : db.session.execute(text("SELECT COUNT(*) FROM ALERT_TABLE WHERE AlertStatus = 'Closed' AND AlertLevel = 'Information'")).scalar(),
    "close_warn" : db.session.execute(text("SELECT COUNT(*) FROM ALERT_TABLE WHERE AlertStatus = 'Closed' AND AlertLevel = 'Warning'")).scalar(),
    "close_error" : db.session.execute(text("SELECT COUNT(*) FROM ALERT_TABLE WHERE AlertStatus = 'Closed' AND AlertLevel = 'Error'")).scalar(),
    "close_crit" : db.session.execute(text("SELECT COUNT(*) FROM ALERT_TABLE WHERE AlertStatus = 'Closed' AND AlertLevel = 'Critical'")).scalar(),
    }
    
    return render_template('dashboard_template.html', alerts_cnt_template = alerts_cnt,
    title_string = ti_string,
    date_string = dt_string, 
    version_string = ver_string, 
    username_string = user_string)
    
@routes_bp.route('/eventmanager/response/<int:AlertId>')
@login_required
def get_response(AlertId):

    table_row = AlertId
    result = db.session.query(Response).filter(Response.AlertId == table_row)

    # Sunday, May 20, 2023 00:00:00
    #
    #
    ti_string = 'Alert Monitor - Responses'
    dt_string = get_date_string()
    ver_string = get_version()
    user_string = current_user.UsersName
    
    return render_template('response_template.html', title='Alert Monitor', responses=result,
    title_string = ti_string,
    date_string = dt_string, 
    version_string = ver_string, 
    username_string = user_string
    )
    
    
    
