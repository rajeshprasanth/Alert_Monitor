#---------------------------------------------------------------------------------------------------------------------------------------------
# This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the 
# Free Software Foundation, either version 3 of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or 
# FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License along with this program. If not, see <https://www.gnu.org/licenses/>. 
#---------------------------------------------------------------------------------------------------------------------------------------------
import os
import sys
from datetime import datetime
from getpass import getpass
import time
from werkzeug.security import generate_password_hash, check_password_hash

from sqlalchemy.ext.automap import automap_base
from sqlalchemy.orm import Session
from sqlalchemy import create_engine
from sqlalchemy import insert,update,delete


import secrets

# directory reach
directory = os.path.dirname(os.path.abspath("__file__"))
# setting path
sys.path.append(os.path.dirname(os.path.dirname(directory)))

#
from apps.config.config import Config
#

def connect_database(Config):
    Base = automap_base()

    try:
        engine = create_engine(Config.SQLALCHEMY_DATABASE_URI)
    except:
        print("Unable to connect to Database")
        exit()
    # reflect the tables
    Base.prepare(autoload_with=engine)

    # mapped classes are now created with names by default
    # matching that of the table name.
    Alert = Base.classes.ALERT_TABLE
    Response = Base.classes.RESPONSE_TABLE
    ApiKey = Base.classes.API_KEY_TABLE
    Users = Base.classes.USERS_TABLE
    
    return engine,Alert,Response,ApiKey,Users
    
def close_database(engine):
    engine.dispose()
    
    
def query_database(engine,Alert,Response,ApiKey,Users):
    session = Session(engine)
    
    
    num_ui_user = session.query(Users).count()
    ui_user = session.query(Users).all()
    
    num_api_user = session.query(ApiKey).count()
    api_user = session.query(ApiKey).all()
    
    
    ui_user_list = []
    api_user_list = []
    
    for row in ui_user:
        ui_user_list.append([row.UsersId,row.UsersName,row.UsersPassword])
    for row in api_user_list:
        api_user_list.append([row.ApiKeyId,row.ApiKeyName,row.ApiKeyHash])
    
    return ui_user_list,api_user_list
    # rudimentary relationships are produced

def clear_screen():
    if(os.name == 'posix'):
        os.system('clear')
    else:
        os.system('cls')

def main_panel():
    while True:
        clear_screen()
        print("=====================================================================")
        print("Alert Monitor Administrative Panel - Main")
        print("=====================================================================")
        print("1. User Management")
        print("2. API Key Management")
        print("3. Service Management")
        print("4. quit")
        print("=====================================================================")
        option = int(input("Enter your option : "))
        if option == 1:
            user_mgmt()
        if option == 2:
            api_key_mgmt()
        if option == 3:
            pass
        if option == 4:
            print("=====================================================================")
            print("Exiting from Alert Monitor Administrative Panel - Main")
            print("=====================================================================")
            exit()
        else:
            print("Invalid Input")
        

def user_mgmt():
    clear_screen()
    print("=====================================================================")
    print("Alert Monitor Administrative Panel - User Management")
    print("=====================================================================")
    print("1. Add User")
    print("2. Modify User")
    print("3. Delete User")
    print("4. Main panel")
    print("5. quit")
    print("=====================================================================")
    option = int(input("Enter your option : "))
    
    
    if option == 1:
        add_user()
    elif option == 2:
        modify_user()
    elif option ==3:
        delete_user()
    elif option == 4:
        main_panel()
    elif option == 5:
        print("=====================================================================")
        print("Exiting from Alert Monitor Administrative Panel - User Management")
        print("=====================================================================")
        exit()
    else:
       print("Invalid Input")
       time.sleep(2)
       user_mgmt()
       
def add_user():
    session = Session(engine)
    num_ui_user = session.query(Users).count()
    ui_user = session.query(Users).all()
    
    ui_user_list = []
    ui_username_list = []
    
    for row in ui_user:
        ui_user_list.append([row.UsersId,row.UsersName,row.UsersPassword])
        
    for row in ui_user_list:
        ui_username_list.append(row[1])
        
        
    while True:
        username = input("Enter New Username : ")
        password = getpass(prompt='Enter New Password : ')
        confirm = input("Confirm (yes/no) : ")
        in_username = username
        in_password = generate_password_hash(password,method='scrypt')
        
        
            
        if confirm == "yes":
        
            try: 
                if in_username not in ui_username_list:
                    new_user = Users(UsersId=None, UsersName=in_username,UsersPassword=in_password)
                    session = Session(engine)
                    session.add(new_user)
                    session.commit()
                    print("User added Successfully!!")
                    time.sleep(2)
                    user_mgmt()
                else:
                    print("User already exist.")
                    time.sleep(2)
                    user_mgmt()
            except:
                print("Unable to add new user.")
                user_mgmt()

               
def modify_user():

    session = Session(engine)
    num_ui_user = session.query(Users).count()
    ui_user = session.query(Users).all()
    
    ui_user_list = []
    ui_username_list = []
    
    for row in ui_user:
        ui_user_list.append([row.UsersId,row.UsersName,row.UsersPassword])
        
    for row in ui_user_list:
        ui_username_list.append(row[1])
        
        
    print("Current userlist ", ui_username_list)
    while True:
        username = input("Enter Username to modify: ")
        in_username = input("Enter New Username to modify: ")
        
        if username == in_username:
            print("Username will not be changed!!!")
        password = getpass(prompt='Enter New Password : ')
        confirm = input("Confirm (yes/no) : ")
        in_password = generate_password_hash(password,method='scrypt')
        
        
            
        if confirm == "yes":
            try:
                if username in ui_username_list:
                    session.query(Users).filter(Users.UsersName == username).update({Users.UsersName: in_username,Users.UsersPassword: in_password})
                    session.commit()
                    print("User modified Successfully!!")
                    time.sleep(2)
                    user_mgmt()
                    
                else:
                    print("User does not exist.")
                    time.sleep(2)
                    
                    
            except:
                print("Unable to modify user.")
                
def delete_user():
    session = Session(engine)
    num_ui_user = session.query(Users).count()
    ui_user = session.query(Users).all()
    
    ui_user_list = []
    ui_username_list = []
    
    for row in ui_user:
        ui_user_list.append([row.UsersId,row.UsersName,row.UsersPassword])
        
    for row in ui_user_list:
        ui_username_list.append(row[1])
        
        
    print("Current userlist ", ui_username_list)
    
    while True:
        username = input("Enter Username to delete: ")
        confirm = input("Confirm (yes/no) : ")
        
        if confirm == "yes":
            try:
                if username in ui_username_list:
                
                
                    delete_row = session.query(Users).filter(Users.UsersName == username).one()
                    session.delete(delete_row)
                    session.commit()
                    print("User deleted Successfully!!")
                    time.sleep(2)
                    user_mgmt()
                    
                else:
                    print("User does not exist.")
                    time.sleep(2)
                    
                    
            except:
                print("Unable to delete user.")

    
def api_key_mgmt():
    clear_screen()
    print("=====================================================================")
    print("Alert Monitor Administrative Panel - API Key Management")
    print("=====================================================================")
    print("1. Add API key")
    print("2. Modify API key")
    print("3. Delete API key")
    print("4. View API key")
    print("5. Main panel")
    print("6. quit")
    print("=====================================================================")
    option = int(input("Enter your option : "))
    
    if option == 1:
        add_api_key()
    elif option == 2:
        modify_api_key()
    elif option ==3:
        delete_api_key()
    elif option == 4:
        view_api_key()
    elif option == 5:
        main_panel()
    elif option == 6:
        print("=====================================================================")
        print("Exiting from Alert Monitor Administrative Panel - API Management")
        print("=====================================================================")
        exit()
    else:
       print("Invalid Input")
       time.sleep(2)
       api_key_mgmt()
       
       
def add_api_key():
    session = Session(engine)
    num_api_user = session.query(ApiKey).count()
    api_user = session.query(ApiKey).all()
    
    api_user_list = []
    api_username_list = []
    
    for row in api_user:
        api_user_list.append([row.ApiKeyId,row.ApiKeyName,row.ApiKeyHash])
        
    for row in api_user_list:
        api_username_list.append(row[1])
        
    while True:
        api_user_name = input("Enter New API Key Name : ")
        confirm = input("Confirm (yes/no) : ")
        in_username = api_user_name
        in_hash = secrets.token_hex(32)
        
        
            
        if confirm == "yes":
        
            #try: 
            if in_username not in api_username_list:
                new_user = ApiKey(ApiKeyId=None, ApiKeyName=in_username,ApiKeyHash=in_hash)
                session = Session(engine)
                session.add(new_user)
                session.commit()
                print("New API user added Successfully!!")
                time.sleep(2)
                api_key_mgmt()
            else:
                print("API User already exist.")
                time.sleep(2)
                api_key_mgmt()
            #except:
            #    print("Unable to add new API user.")
                #api_key_mgmt()
       
def modify_api_key():

    session = Session(engine)
    num_api_user = session.query(ApiKey).count()
    api_user = session.query(ApiKey).all()
    
    api_user_list = []
    api_username_list = []
    
    for row in api_user:
        api_user_list.append([row.ApiKeyId,row.ApiKeyName,row.ApiKeyHash])
        
    for row in api_user_list:
        api_username_list.append(row[1])
        
    print("Current userlist ", api_username_list)
    while True:
        username = input("Enter API user to modify: ")
        in_username = input("Enter New API Username to modify: ")
        
        if username == in_username:
            print("Username will not be changed!!!")
        confirm = input("Confirm (yes/no) : ")
        in_hash = secrets.token_hex(32)
        
        
            
        if confirm == "yes":
            try:
                if username in api_username_list:
                    session.query(ApiKey).filter(ApiKey.ApiKeyName == username).update({ApiKey.ApiKeyName: in_username,ApiKey.ApiKeyHash: in_hash})
                    session.commit()
                    print("API User modified Successfully!!")
                    time.sleep(2)
                    api_key_mgmt()
                    
                else:
                    print("API User does not exist.")
                    time.sleep(2)
                    
                    
            except:
                print("Unable to modify API user.")       
                
                
                
def delete_api_key():
    session = Session(engine)
    num_api_user = session.query(ApiKey).count()
    api_user = session.query(ApiKey).all()
    
    api_user_list = []
    api_username_list = []
    
    for row in api_user:
        api_user_list.append([row.ApiKeyId,row.ApiKeyName,row.ApiKeyHash])
        
    for row in api_user_list:
        api_username_list.append(row[1])
        
    print("Current userlist ", api_username_list)
    
    while True:
        username = input("Enter Username to delete: ")
        confirm = input("Confirm (yes/no) : ")
        
        if confirm == "yes":
            try:
                if username in api_username_list:
                
                
                    delete_row = session.query(ApiKey).filter(ApiKey.ApiKeyName == username).one()
                    session.delete(delete_row)
                    session.commit()
                    print("API User deleted Successfully!!")
                    time.sleep(2)
                    api_key_mgmt()
                    
                else:
                    print("API User does not exist.")
                    time.sleep(2)
                    
                    
            except:
                print("Unable to delete API user.")
                
def view_api_key():
    session = Session(engine)
    num_api_user = session.query(ApiKey).count()
    api_user = session.query(ApiKey).all()
    
    api_user_list = []
    api_username_list = []
    
    for row in api_user:
        api_user_list.append([row.ApiKeyId,row.ApiKeyName,row.ApiKeyHash])
        
    for row in api_user_list:
        api_username_list.append(row[1])
        
    for row in api_user_list:
        print(row)
        
    option = input("Enter return to go back ")
    if option == "":
        api_key_mgmt()
#
#
#


       
engine,Alert,Response,ApiKey,Users = connect_database(Config)
main_panel()
close_database(engine)
exit()
    
#def modify_user:
# def delete_user:
# def add_api_key;
# def modify_api_key:
# def delete_api_key:
