#---------------------------------------------------------------------------------------------------------------------------------------------
# This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the 
# Free Software Foundation, either version 3 of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or 
# FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License along with this program. If not, see <https://www.gnu.org/licenses/>. 
#---------------------------------------------------------------------------------------------------------------------------------------------
import requests
from datetime import datetime
import sys
import configparser

import argparse

import logging



#
# API ENDPOINTS
#
post_endpoint = 'api/alerts/insert'
put_endpoint = 'api/alerts/update'
get_endpoint = 'api/alerts'
#
major_version = 1
minor_version = 1
revision_version = 1
#

def get_version(major_version,minor_version,revision_version):
    __version_info__ = (str(major_version), str(minor_version), str(revision_version))
    __version__ = '.'.join(__version_info__)
    return __version__
  

def parse_option():

    operation_choices = ['insert', 'update', 'close']

    formatter = lambda prog: argparse.HelpFormatter(prog,max_help_position=82)
    parser = argparse.ArgumentParser(formatter_class=formatter,add_help=True)
    parser.add_argument('-v','--version',help = 'prints version of program',action='store_true')
    parser.add_argument('-m','--mode', choices = operation_choices,help = 'mode to run agent.py, one of insert, update, close')


    insert_parser = parser.add_argument_group('insert', 'Options for insert mode')
    insert_parser.add_argument('-an', '--alert-name', metavar='[name]', help = 'Alert Name')
    insert_parser.add_argument('-am', '--alert-message', metavar='[message]', help = 'Alert Message')
    insert_parser.add_argument('-al', '--alert-level', metavar='[level]', help = 'Alert Level, one of Information, Warning, Error, Critical')
    insert_parser.add_argument('-ts', '--trigger-source', metavar='[source]', help = 'Trigger Source')

    update_parser = parser.add_argument_group('update/close', 'Options for update/close mode')
    update_parser.add_argument('-rm', '--response-message', metavar='[message]', help = 'Response message')
    update_parser.add_argument('-ub', '--updated-by', metavar='[updater]', help = 'Updated by')
    update_parser.add_argument('-ai', '--alert-id', metavar='[id]',  help = 'Alert Id')
    
    args = parser.parse_args()
    
    if args.version:
        print("agent.py     Version: %s" %(get_version()))
        exit()
    if len(sys.argv) == 1:
        parser.print_help()
        exit()
        
    if args.mode == "insert":
        if len(sys.argv) != 11:
            parser.print_help()
            exit()
    elif args.mode == "update" or args.mode == "close":
         if len(sys.argv) != 9:
            parser.print_help()
            exit()
            
    return args

def read_config_file():
    config = configparser.ConfigParser()
    #
    # assume ssl is not enabled by default
    prefix = 'http'
    #
    try:
        config.read('agent_config.ini')
        host = config['API_CONFIG']['API_HOST_ADDRESS']
        port = config['API_CONFIG']['API_PORT_NUMBER']
        apikeyfile = config['API_CONFIG']['API_KEY_FILE']
        #
        ssl_enabled = config['SSL_CONFIG']['SSL_ENABLED']
        #
        logfile = config['LOG_CONFIG']['LOGFILE']
        #
        if ssl_enabled == 1:
            prefix = 'https'    
        #
        url_post = prefix + "://" + host + ":" + port + "/" + post_endpoint
        url_put = prefix + "://" + host + ":" + port + "/" + put_endpoint
        url_get = prefix + "://" + host + ":" + port + "/" + get_endpoint
        #
        config_file = {}
        
        config_file['url_post'] = url_post
        config_file['url_put'] = url_put
        config_file['url_get'] = url_get
        config_file['logfile'] = logfile
        config_file['apikeyfile'] = apikeyfile
       
    except:
        print("Cannot open agent_config.ini in current directory")
        exit()
    #

    
    return config_file

    
def check_trigger_source(trigger_source):

    try:
        with open('apikey.dat') as f:
            lines = f.readlines()
        
        for line in lines:
            temp_line = line.split("|")
            
            if temp_line[1] == trigger_source:
                api_user = (temp_line[1])
                api_hash = (temp_line[2].replace("\n",""))
                headers = {'x-api-key' : api_hash}
        
                
                return headers
    except:
        print("apikey.dat not found in current directory")
        exit()
    
def insert_alert(cmdline_arg,config_file):
    now = datetime.now()
    date_time = now.strftime("%m/%d/%Y %H:%M:%S")
        

    data = {
    "AlertName" : cmdline_arg.alert_name,
    "AlertStatus" : "Open",
    "AlertMsg" : cmdline_arg.alert_message,
    "AlertLevel" : cmdline_arg.alert_level,
    "TriggerTime" : date_time,
    "TriggerSource" : cmdline_arg.trigger_source
    }
    
    data_header = check_trigger_source(cmdline_arg.trigger_source)
    
    try:
        log_msg = 'Sending data from insert_alert to API Endpoint: ' + config_file["url_post"] + ' - Sent Data: ' + str(data)
        logging.info(log_msg)
        response = requests.post(config_file["url_post"], headers = data_header, json=data)
    except:
        print("API services might be down. Check the logs for more information.")
        logging.critical('No Response from API endpoint ' + config_file["url_post"] + '. API Services might be down.')
        exit() 
            
    if response.status_code == 200:
        log_msg = 'Message from insert_alert - ' + config_file["url_post"] + ' - POST : OK - Response code: ' + str(response.status_code)
        print(log_msg)
        print("Check the logs for more information.")
        logging.info(log_msg +' - Response : '+ str(response.json()))
        exit()
    else:
        log_msg = 'Message from insert_alert - ' + config_file["url_post"] + ' - POST : Failed - Response code: ' + str(response.status_code)
        print(log_msg)
        print("Check the logs for more information.")
        logging.error(log_msg)
        exit()
        
def update_alert(cmdline_arg,config_file):
    now = datetime.now()
    date_time = now.strftime("%m/%d/%Y %H:%M:%S")
    
    data = { 
    "ResponseMsg": cmdline_arg.response_message,
    "ResponseTime": date_time,
    "UpdatedBy": cmdline_arg.updated_by,
    "AlertStatus":"Pending",
    "AlertId":int(cmdline_arg.alert_id)
    }
    
    data_header = check_trigger_source(cmdline_arg.updated_by)

    try:
        log_msg = 'Sending data from update_alert to API Endpoint: ' + config_file["url_put"] + ' - Sent Data: ' + str(data)
        logging.info(log_msg)
        response = requests.put(config_file["url_put"], headers = data_header, json=data)
    except:
        print("API services might be down. Check the logs for more information.")
        logging.critical('No Response from API endpoint ' + config_file["url_put"] + '. API Services might be down.')
        exit() 
            
    if response.status_code == 200:
        log_msg = 'Message from update_alert - ' + config_file["url_put"] + ' - PUT : OK - Response code: ' + str(response.status_code)
        print(log_msg)
        print("Check the logs for more information.")
        logging.info(log_msg +' - Response : '+ str(response.json()))
        exit()
    else:
        log_msg = 'Message from update_alert - ' + config_file["url_put"] + ' - PUT : Failed - Response code: ' + str(response.status_code)
        print(log_msg)
        print("Check the logs for more information.")
        logging.error(log_msg)
        exit()
        
def close_alert(cmdline_arg,config_file):
    now = datetime.now()
    date_time = now.strftime("%m/%d/%Y %H:%M:%S")

    data = { 
    "ResponseMsg": cmdline_arg.response_message,
    "ResponseTime": date_time,
    "UpdatedBy": cmdline_arg.updated_by,
    "AlertStatus":"Pending",
    "AlertId":int(cmdline_arg.alert_id)
    }
       
    data_header = check_trigger_source(cmdline_arg.updated_by)
   
    try:
        log_msg = 'Sending data from close_alert to API Endpoint: ' + config_file["url_put"] + ' - Sent Data: ' + str(data)
        logging.info(log_msg)
        response = requests.put(config_file["url_put"], headers = data_header, json=data)
    except:
        print("API services might be down. Check the logs for more information.")
        logging.critical('No Response from API endpoint ' + config_file["url_put"] + '. API Services might be down.')
        exit() 
            
    if response.status_code == 200:
        log_msg = 'Message from close_alert - ' + config_file["url_put"] + ' - PUT : OK - Response code: ' + str(response.status_code)
        print(log_msg)
        print("Check the logs for more information.")
        logging.info(log_msg +' - Response : '+ str(response.json()))
        exit()
    else:
        log_msg = 'Message from close_alert - ' + config_file["url_put"] + ' - PUT : Failed - Response code: ' + str(response.status_code)
        print(log_msg)
        print("Check the logs for more information.")
        logging.error(log_msg)
        exit()

cmdline_arg = parse_option()
config_file = read_config_file()

logging.basicConfig(filename=config_file['logfile'], filemode='a', format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',datefmt='%d-%b-%y %H:%M:%S',level=logging.INFO)

    

if cmdline_arg.mode == "insert":
    insert_alert(cmdline_arg,config_file)

    
if cmdline_arg.mode == "update":
    update_alert(cmdline_arg,config_file)
    
if cmdline_arg.mode == "close":
    close_alert(cmdline_arg,config_file)

exit()