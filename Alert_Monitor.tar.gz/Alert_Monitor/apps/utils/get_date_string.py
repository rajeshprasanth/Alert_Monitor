from datetime import datetime
#
#
def get_date_string():
    now = datetime.now()
    
    current_day_full_text = now.strftime('%A')
    current_month_text = now.strftime('%B')
    current_day = now.strftime('%d')
    
    current_year_full = now.strftime('%Y')
    
    current_second= now.strftime('%S')
    current_minute = now.strftime('%M') 
    current_hour = now.strftime('%H')
    current_timzone = now.strftime('%Z')
    
    dt_string = current_day_full_text + ', ' + current_month_text + ' ' + current_day + ', ' + current_year_full + '   ' + current_hour + ':' + current_minute + ':' + current_second + current_timzone
   
    return dt_string